# Introduction to FreeFEM finite element programming

This repository contains codes and examples to learn FreeFEM basics, which  accompanies the YouTube playlist [Introduction to finite element using FreeFEM](https://www.youtube.com/playlist?list=PL6fjYEpJFi7Wu9ZFlak7r0QgrF0aNi8H1).
